rootProject.name = "ShadowRiftWebView"
include(":app")
