Shadow Rift - WebView Android app
=================================

What this is
-------------
A minimal Android (Kotlin) app that opens the URL https://shadow-rift-dimensions.lovable.app/ in a WebView.
This project is ready to import into Android Studio and build an APK.

How to build (Android Studio)
-----------------------------
1. Download and unzip this project.
2. Open Android Studio -> Open -> select the project folder (the folder containing settings.gradle.kts).
3. If prompted, upgrade Gradle plugin or accept the recommended versions so Android Studio can sync and download required components.
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. The APK will appear under app/build/outputs/apk/debug/ or the release path if you build a signed release.

How to build (command line)
---------------------------
- Install Android SDK and set ANDROID_HOME / ANDROID_SDK_ROOT
- From project root run: ./gradlew assembleDebug

Notes & Checklist
-----------------
- You must sign the app for Play Store release.
- Ensure the URL is reachable and supports being embedded in a WebView.
- If your site forces external files or advanced features (like WebGL), test thoroughly.
- For a Progressive Web App (PWA) prefer using Trusted Web Activity (TWA) or wrappers like Capacitor for better integration.

If you want, I can also generate a Capacitor or TWA project instead (better for PWAs).

